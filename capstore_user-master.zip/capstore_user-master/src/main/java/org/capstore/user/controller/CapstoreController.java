package org.capstore.user.controller;



import org.capstore.user.model.Address;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class CapstoreController {

	@RequestMapping("/CapStoreAfterLogin")
	public String capStoreAfterLogin() {
		
		return "CapStoreAfterLogin";
	}
	@RequestMapping("/CapStoreHomeAfter1")
	public String capStoreHomeFull1() {
		
		return "CapStoreHomeAfter1";
	}
	
	
	@RequestMapping("/CapStoreHome_full")
	public String capStoreHomeFull() {
		
		return "CapStoreHome_full";
	}
	
	@RequestMapping("/CapStoreHome")
	public String capStoreHome() {
		
		return "CapStoreHome";
	}
	
	@RequestMapping("/Page1_full")
	public String page1() {
		
		return "Page1_full";
	}
	
	@RequestMapping("/product")
	public String product() {
		
		return "product";
	}
	
	@RequestMapping("/Product_full")
	public String productFull() {
		
		return "Product_full";
	}


	@RequestMapping("/shippingAddressCap")
		public String shippingPage(ModelMap map) {
		final String uri="http://localhost:8090/capstoreApp/api/v1/address/1";
		RestTemplate restTemplate=new RestTemplate();
		
		Address[] addresses= restTemplate.getForObject(uri, Address[].class);
		System.out.println("hiiiiiiiiiii");
		map.put("addresses", addresses);
		return "shippingAddressCap";
	}
	@RequestMapping("/paymentCap")
	public String paymentPage() {
	
	return "PaymentCap";
}
	@RequestMapping("/paymentSuccess")
	public String paymentSuccessPage() {
	
	return "paymentSuccessfullCap";
}
	
	@RequestMapping("/Wishlist_full")
	public String productFull2() {
		
		return "Wishlist_full";
	}
	@RequestMapping("/WishList")
	public String productFull3() {
		
		return "WishList";
	}
	
	
	
	
}
