package org.capstore.user.controller;

import java.util.Date;

import org.capstore.user.model.Address;
import org.capstore.user.model.Customer;
import org.capstore.user.model.Email;
import org.capstore.user.model.Order;
import org.capstore.user.model.Shipping;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class CapstoreController {

	@RequestMapping("/CapStoreAfterLogin")
	public String capStoreAfterLogin() {
		
		return "CapStoreAfterLogin";
	}
	@RequestMapping("/CapStoreHomeAfter1")
	public String capStoreHomeFull1() {
		
		return "CapStoreHomeAfter1";
	}
	
	
	@RequestMapping("/CapStoreHome_full")
	public String capStoreHomeFull() {
		
		return "CapStoreHome_full";
	}
	
	@RequestMapping("/CapStoreHome")
	public String capStoreHome() {
		
		return "CapStoreHome";
	}
	
	@RequestMapping("/Page1_full")
	public String page1() {
		
		return "Page1_full";
	}
	
	@RequestMapping("/product")
	public String product() {
		
		return "product";
	}
	
	@RequestMapping("/Product_full")
	public String productFull() {
		
		return "Product_full";
	}


	@RequestMapping("/shippingAddressCap")
		public String shippingPage(ModelMap map,@ModelAttribute("address") Address address,@ModelAttribute("address1") Address address1,BindingResult result) {
		final String uri="http://localhost:8090/capstoreApp/shippingRest/address/1";
		RestTemplate restTemplate=new RestTemplate();
		
		Address[] addresses= restTemplate.getForObject(uri, Address[].class);
		
		map.put("addresses", addresses);
		return "shippingAddressCap";
	}
	
	
	@RequestMapping("/paymentCap")
	public String paymentPage( @ModelAttribute("address") Address address,@ModelAttribute("address1") Address address1,BindingResult result) {
		Shipping shipping=new  Shipping();
		
		Email  email=new Email();
		//getting customer details
		/*Customer customer=new Customer();
		customer.setCustomerId(1);
		customer.setCustomerName("drgrd");	
		customer.setEmailId("prani@gmail.com");*/
		
		
		//http://localhost:8090/capstoreApp/shippingRest/customer/1
		//getting order details
		/*Order order=new Order();
		order.setOrderId(1);*/
		
		if(address1.getAddressId()!=0) {
			//System.out.println("address existed");
			shipping.setShippingAddress(address1);
			//System.out.println("address1.getStreetNumber()+address1.getCity()+address1.getState()+\r\n" + 
				//	"			address1.getCountry()+address1.getZipcode()");
			email.setBody("Address verification");
			/*address1.getStreetNumber()+address1.getCity()+address1.getState()+
			address1.getCountry()+address1.getZipcode()*/
		}
		else {
	
				
		//address.setCustomer(customer);
		final String uri="http://localhost:8090/capstoreApp/shippingRest/addres/1";
		RestTemplate restTemplate=new RestTemplate();
		restTemplate.postForEntity(uri,address,Address.class);
		
		email.setBody("New Address Verification");
		
	//	shipping.setShippingAddress(addre);
		}
		
		/*shipping.setCustomer(customer);
		shipping.setOrder(order);*/
		
		//System.out.println("before");
		final String uri1="http://localhost:8090/capstoreApp/shippingRest/shipping/1";
		RestTemplate restTemplate1=new RestTemplate();
		restTemplate1.postForEntity(uri1,shipping,Shipping.class);
		
		email.setDate(new Date());
		email.setFrom_emailId("Capstore@gmail.com");
		email.setSubject("Address verification");
		//email.setTo_emailId(customer.getEmailId());
		final String uri2="http://localhost:8090/capstoreApp/shippingRest/email";
		RestTemplate restTemplate2=new RestTemplate();
		restTemplate2.postForEntity(uri2,email,Email.class);
		return "PaymentCap";
}
	@RequestMapping("/paymentSuccess")
	public String paymentSuccessPage() {
	
	return "paymentSuccessfullCap";
}
	
	@RequestMapping("/Wishlist_full")
	public String productFull2() {
		
		return "Wishlist_full";
	}
	@RequestMapping("/WishList")
	public String productFull3() {
		
		return "WishList";
	}
	
	
	
	
}
