package org.cap.pilot.rest.dao;

import javax.transaction.Transactional;

import org.cap.pilot.rest.model.Pilot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
//@Transactional
@Repository("pilotDao")
public interface IPilotDao extends JpaRepository<Pilot, Integer> {

}
