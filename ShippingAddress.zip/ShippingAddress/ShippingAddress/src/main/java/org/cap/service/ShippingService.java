package org.cap.service;

import java.util.List;

import org.cap.model.Address;



public interface ShippingService {
	public void save(Address address);
	public List<Address> getAll();
	public void delete(Integer addId) ;
	public void update(Address address);
	public Address findPilot(Integer addId);
}
