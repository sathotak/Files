package org.cap.dao;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Address;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("shippingDao")
//@Transactional
public class ShippingDaoImp implements ShippingDao{
	@PersistenceContext
private EntityManager entityManager;
	@Override
	@Transactional
	public void save(Address address) {
		
		/*if(address.getAddId()!=0)
			entityManager.merge(address);
			else*/
				entityManager.persist(address);
	}
	@Transactional(readOnly=true)
	@Override
	public List<Address> getAll() {
		List<Address> address=entityManager.createQuery("from Address").getResultList();
		return address;
	}

	@Transactional
	@Override
	public void delete(Integer addId) {
		Address address= entityManager.find(Address.class, addId);
		entityManager.remove(address);
	}
	@Transactional
	@Override
	public Address findPilot(Integer addId) {
		Address address=entityManager.find(Address.class,addId );
		return address;
	}
	@Transactional
	@Override
	public void update(Address address) {
		if(address.getAddId()!=0)
			entityManager.merge(address);
		else
			entityManager.persist(address);
		
		
	}

}












   
	
 
