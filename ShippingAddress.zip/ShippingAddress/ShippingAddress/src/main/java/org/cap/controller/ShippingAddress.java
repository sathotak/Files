package org.cap.controller;

import java.util.List;

import javax.validation.Valid;

import org.cap.model.Address;
import org.cap.service.ShippingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ShippingAddress {
	
	@Autowired
	private ShippingService shippingService;
	
	@RequestMapping("/")
	public String shippingAddress(ModelMap map,@ModelAttribute("address") Address address,BindingResult result) {
		List<Address> addresses=shippingService.getAll();
		map.put("addresses", addresses);
		System.out.println(address);
		return "ShippingAddress";
		
	}
	@RequestMapping("/moneyPage")
	public String moneyTrans(@Valid @ModelAttribute("address") Address address) {
		System.out.println(address);
		if(address!=null)
		shippingService.save(address);
		return "moneyTrans";
	}
	}
