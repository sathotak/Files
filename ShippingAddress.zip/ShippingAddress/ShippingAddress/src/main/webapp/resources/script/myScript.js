window.onload= function(){
	document.getElementById('altAddress').style.display='none';
	}

function validateShippingAddForm(){
	
	var add=myform.address.value;
	var city=myform.city.value;
	var state=myform.state.value;
	var country=myform.country.value;
	var zipcode=myform.zipcode.value;
	
	var flag=false;
	if(document.getElementById('altAdd').checked){
	if(add=="" || add==null)
	{
	flag=false;
		document.getElementById('address').innerHTML=" * Please enter Address.";
	}
	else if(city=="" || city==null)
	{
	flag=false;
	document.getElementById('address').innerHTML="";
	document.getElementById('city').innerHTML=" * Please enter City.";
	}
	else if(state=="" || state==null)
	{
	flag=false;
	document.getElementById('address').innerHTML="";
	document.getElementById('city').innerHTML="";
	document.getElementById('state').innerHTML=" * Please enter State.";
	}
	else if(country=="" || country==null)
	{
	flag=false;
	document.getElementById('address').innerHTML="";
	document.getElementById('city').innerHTML="";
	document.getElementById('state').innerHTML="";
	document.getElementById('country').innerHTML=" * Please select Country.";
	}
	else if(zipcode=="" || zipcode==null)
	{
	flag=false;
	document.getElementById('address').innerHTML="";
	document.getElementById('city').innerHTML="";
	document.getElementById('state').innerHTML="";
	document.getElementById('country').innerHTML="";
	document.getElementById('zipcode').innerHTML=" * Please enter Zipcode.";
	}
	
	else{
		flag=true;
		document.getElementById('address').innerHTML="";
		document.getElementById('city').innerHTML="";
		document.getElementById('state').innerHTML="";
		document.getElementById('altMobilenum').innerHTML="";
		document.getElementById('zipcode').innerHTML="";
		
	}
		return flag;
	}
	else
		return true;
}



function showAltAdd(){
			document.getElementById('altAddress').style.display='block';
	
	
}
