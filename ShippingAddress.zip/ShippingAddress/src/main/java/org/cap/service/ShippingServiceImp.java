package org.cap.service;

import java.util.List;

import org.cap.dao.ShippingDao;
import org.cap.model.Address;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("shippingService")
public class ShippingServiceImp implements ShippingService{
	@Autowired
private ShippingDao shippingDao;
	@Override
	public void save(Address address) {
		shippingDao.save(address);
		
	}
	@Override
	public List<Address> getAll() {
		
		return shippingDao.getAll();
	}
	@Override
	public void delete(Integer addId) {
		shippingDao.delete(addId);
	}
	@Override
	public void update(Address address) {
		shippingDao.update(address);
		
	}
	@Override
	public Address findPilot(Integer addId) {
		// TODO Auto-generated method stub
		return shippingDao.findPilot(addId);
	}

}
