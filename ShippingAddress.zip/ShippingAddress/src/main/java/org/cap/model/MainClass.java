package org.cap.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {
	public static void main(String[] args) {
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=factory.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		Address address=new Address();
		address.setAddId(1);
		address.setAddSt("55/1");
		address.setCity("Hyd");
		address.setState("TS");
		address.setCountry("IN");
		address.setZipcode("500056");
		
		/*Address address1=new Address();
		address1.setAddSt("22/1");
		address1.setCity("chennai");
		address1.setState("TN");
		address1.setCountry("IN");
		address1.setZipcode("600063");
		
		Address address2=new Address();
		address2.setAddSt("85/1");
		address2.setCity("Mumbai");
		address2.setState("KS");
		address2.setCountry("IN");
		address2.setZipcode("454222");*/
		transaction.commit();
		
}
}