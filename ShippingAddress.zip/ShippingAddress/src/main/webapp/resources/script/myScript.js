window.onload= function(){
document.getElementById('altAddress').style.display='none';
}



function validateShippingAddForm(){
var myform=document.getElementById("myform");
var add=myform["addSt"].value;
var city=myform["city"].selectedIndex;
var state=myform["state"].selectedIndex;
var country=myform["country"].selectedIndex;
var zipcode=myform["zipcode"].value;
var validZip=/^\d{6}$/;
var flag=false;

if(add=="" || add==null)
{
flag=false;
document.getElementById('address').innerHTML=" * Please enter Address.";
}
else if(city=="" || city==null)
{
flag=false;
document.getElementById('address').innerHTML="";
document.getElementById('City').innerHTML=" * Please enter City.";
}
else if(state=="" || state==null)
{
flag=false;
document.getElementById('address').innerHTML="";
document.getElementById('City').innerHTML="";
document.getElementById('State').innerHTML=" * Please enter State.";
}
else if(country=="" || country==null)
{
flag=false;
document.getElementById('address').innerHTML="";
document.getElementById('City').innerHTML="";
document.getElementById('State').innerHTML="";
document.getElementById('count').innerHTML=" * Please select Country.";
}
else if(zipcode=="" || zipcode==null)
{
flag=false;
document.getElementById('address').innerHTML="";
document.getElementById('City').innerHTML="";
document.getElementById('State').innerHTML="";
document.getElementById('count').innerHTML="";
document.getElementById('zipc').innerHTML=" * Please enter Zipcode.";
}
else if(validZip.test(zipcode) == false)
{
	flag=false;
	document.getElementById('address').innerHTML="";
	document.getElementById('City').innerHTML="";
	document.getElementById('State').innerHTML="";
	document.getElementById('count').innerHTML="";
	document.getElementById('zipc').innerHTML=" * Please enter valid Zipcode.";
}
else{
flag=true;
document.getElementById('address').innerHTML="";
document.getElementById('City').innerHTML="";
document.getElementById('State').innerHTML="";
document.getElementById('count').innerHTML="";
document.getElementById('zipc').innerHTML="";
}
return flag;
}



function showAltAdd(){
document.getElementById('altAddress').style.display='block';
document.getElementById('curAdd').innerHTML="";
}

function validateAddForm(){
var	flag=false;
	if(document.getElementById('currentAdd').checked){
		document.getElementById('address').innerHTML="";
	document.getElementById('City').innerHTML="";
	document.getElementById('State').innerHTML="";
	document.getElementById('count').innerHTML="";
	document.getElementById('zipc').innerHTML="";
			return true;
	}
	else{
		document.getElementById('curAdd').innerHTML="Select Address or enter alternate address";
		return flag;
	}
		
}
