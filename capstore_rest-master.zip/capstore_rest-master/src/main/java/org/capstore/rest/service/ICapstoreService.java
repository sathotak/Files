package org.capstore.rest.service;

import java.util.List;

import org.capstore.rest.model.Address;

public interface ICapstoreService {
	public List<Address> findAll(Integer custId);
	
}
