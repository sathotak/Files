package com.cg.dao;

import java.util.List;

import com.cg.model.HotelDetails;

public interface IBookingDao {

	public List<HotelDetails> getHotelDetails();

}
