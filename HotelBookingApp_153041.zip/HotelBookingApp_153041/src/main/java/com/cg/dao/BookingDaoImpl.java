package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.HotelDetails;
/**
 * Class : BookingDao
 * Author : Praneetha
 * Date :28th July, 2018
 * Purpose : To manipulate data stored in Database
 * No. of Methods : 1
 * 
 */
@Repository("bookingDao")
@Transactional
public class BookingDaoImpl implements IBookingDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	/**
	 * Method Name : getAllEmployees
	 * Parameters :Nil
	 * Return type : List of HotelDetails
	 * Purpose :Retrieves all the data from the underlying data base
	 * Author : Praneetha
	 * Date of Creation : 28th July, 2018
	 * Last Modified date : 28th July, 2018
	 */
	@Override
	@Transactional
	public List<HotelDetails> getHotelDetails() {
		List<HotelDetails> hotelDetails =entityManager.createQuery("from HotelDetails").getResultList();
		return hotelDetails;
	}
	


}
