package com.cg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="HotelDetails")
public class HotelDetails {

	@Id
	private int id;
	private String name;
	private double rate;
	private String rating;
	private int availableRooms;

	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public double getRate() {
		return rate;
	}


	public void setRate(double rate) {
		this.rate = rate;
	}


	public String getRating() {
		return rating;
	}


	public void setRating(String rating) {
		this.rating = rating;
	}


	public int getAvailableRooms() {
		return availableRooms;
	}


	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}


	public HotelDetails(int id, String name, double rate, String rating, int availableRooms) {
		super();
		this.id = id;
		this.name = name;
		this.rate = rate;
		this.rating = rating;
		this.availableRooms = availableRooms;
	}


	@Override
	public String toString() {
		return "HotelDetails [id=" + id + ", name=" + name + ", rate=" + rate + ", rating=" + rating
				+ ", availableRooms=" + availableRooms + "]";
	}


	public HotelDetails() {
		super();
	}
	
	
}
