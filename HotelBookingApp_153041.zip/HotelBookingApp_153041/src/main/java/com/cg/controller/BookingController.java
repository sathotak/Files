package com.cg.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.model.HotelDetails;
import com.cg.service.IBookingService;
@Controller
public class BookingController {
	private String hotelName;
	@Autowired
	private IBookingService bookingService;
	
	
	
	@RequestMapping("/")
	public String showProduct(ModelMap map)
	{	
		List<HotelDetails> hotelDetails=bookingService.getHotelDetails();
		map.put("hotelDetails", hotelDetails);
		return "HotelDetails";
	}
	
	@RequestMapping("/hotelBooking/{name}")
	public String bookingConfirmation(@PathVariable("name")String name) {
		hotelName=name;
		return "HotelBooking";
		
	}
	
	@RequestMapping("/hotelBooking/bookingConfirmation")
	public ModelAndView bookingConfirmed() {
		return new ModelAndView("BookingConfirmation","hotelName",hotelName);
	}
	
}