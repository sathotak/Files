package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IBookingDao;
import com.cg.model.HotelDetails;

@Service("bookingService")
public class BookingServiceImpl implements IBookingService {
	
	@Autowired
	private IBookingDao bookingDao;

	@Override
	public List<HotelDetails> getHotelDetails() {
		// TODO Auto-generated method stub
		return bookingDao.getHotelDetails();
	}
	
		
		
	
}
