package org.cap.pilot.rest.controller;

import java.util.List;

import org.cap.pilot.rest.model.Pilot;
import org.cap.pilot.rest.service.IPilotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class PilotRestController {
@Autowired
private IPilotService pilotService;
	@GetMapping("/pilots")
	public ResponseEntity<List<Pilot>> getAllPilots(){
		List<Pilot> pilots=pilotService.getAll();
	 if(pilots.isEmpty())
		 return new ResponseEntity("sorry pilot with id does not exist",HttpStatus.NOT_FOUND);
	 return new ResponseEntity<List<Pilot>>(pilots,HttpStatus.OK);
	}
	@PostMapping("/pilots")
	public ResponseEntity<Pilot> createPilot(@RequestBody Pilot pilot){
		pilotService.edit(pilot);
		
		return new ResponseEntity<Pilot>(pilot,HttpStatus.OK);
	}
	@DeleteMapping("/pilots/{pilotId}")
	public void deletePilot(@PathVariable("pilotId") Integer pilotId) {
		
		pilotService.delete(pilotId);
		
	}
	@GetMapping("/pilot/{pilotId}")
	public ResponseEntity<Pilot> updatePilot(@PathVariable("pilotId") Integer pilotId) {
		
	Pilot pilot=	pilotService.findPilot(pilotId);
		 if(pilot==null)
			 return new ResponseEntity("sorry pilot with id does not exist",HttpStatus.NOT_FOUND);
		 return new ResponseEntity<Pilot>(pilot,HttpStatus.OK);
	}
	@PutMapping("/update")
    public ResponseEntity<Pilot> updatePilot(@RequestBody Pilot pilot) {
		pilotService.edit(pilot);
		return new ResponseEntity<Pilot>(pilot,HttpStatus.OK);
	}
}
