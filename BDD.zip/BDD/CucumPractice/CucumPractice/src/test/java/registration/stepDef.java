package registration;

import static org.junit.Assert.assertEquals;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.ConferenceRegistrationPageBean;
import pages.PaymentDetailsPageBean;

public class stepDef {
	
	private WebDriver driver;
	private ConferenceRegistrationPageBean conPageBean;
	private PaymentDetailsPageBean payPageBean;
	
	@Before
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		conPageBean= new ConferenceRegistrationPageBean(driver);
		payPageBean=new PaymentDetailsPageBean(driver);
	}
	
	@Given("^Registration form is open$")
	public void registration_form_is_open() throws Throwable {
		
	   driver.get("C:\\Users\\sathotak\\Documents\\workspace-sts-3.9.4.RELEASE\\BDD\\CucumPractice\\CucumPractice\\src\\main\\webapp\\ConferenceRegistartion.html");
	  
	}

	@When("^I blindly click on next$")
	public void i_blindly_click_on_next() throws Throwable {   
		conPageBean.setBtn(); 
	}

	@Then("^Alert message for first Name will be raised$")
	public void alert_message_for_first_Name_will_be_raised() throws Throwable {
	    	assertEquals(driver.switchTo().alert().getText(), "Please fill the First Name");
	    	Thread.sleep(500);
	}

	@When("^I enter the first Name and press next$")
	public void i_enter_the_first_Name_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
	    conPageBean.setFirstName("Sai");
	    conPageBean.setBtn(); 
	}

	@Then("^Alert message for last Name will be raised$")
	public void alert_message_for_last_Name_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Last Name");
    	Thread.sleep(500);
	}

	@When("^I enter the last Name and press next$")
	public void i_enter_the_last_Name_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conPageBean.setFirstName("Sai");
		conPageBean.setLastName("Praneetha");
	    conPageBean.setBtn(); 
	}

	@Then("^Alert message for email will be raised$")
	public void alert_message_for_email_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Email");
    	Thread.sleep(500);
	}

	@When("^I enter the invalid email and press next$")
	public void i_enter_the_invalid_email_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conPageBean.setFirstName("Sai");
		conPageBean.setLastName("Praneetha");
		conPageBean.setEmail("prani.gmailcom");
	    conPageBean.setBtn(); 
	}

	@Then("^Alert message for enter valid email id will be raised$")
	public void alert_message_for_enter_valid_email_id_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please enter valid Email Id.");
    	Thread.sleep(500);
	}

	@When("^I enter the valid email and press next$")
	public void i_enter_the_valid_email_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conPageBean.setFirstName("Sai");
		conPageBean.setLastName("Praneetha");
		conPageBean.setEmail("prani@gmailcom");
	    conPageBean.setBtn(); 
	}

	@Then("^Alert message for enter phoneno will be raised$")
	public void alert_message_for_enter_phoneno_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Contact No.");
    	Thread.sleep(500);
	}

	@When("^I enter the invalid phoneno  and press next$")
	public void i_enter_the_invalid_phoneno_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conPageBean.setFirstName("Sai");
		conPageBean.setLastName("Praneetha");
		conPageBean.setEmail("prani@gmailcom");
		conPageBean.setPhone("12345");
	    conPageBean.setBtn(); 
	}

	@Then("^Alert message for enter valid phoneno will be raised$")
	public void alert_message_for_enter_valid_phoneno_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please enter valid Contact no.");
    	Thread.sleep(500);
	}

	@When("^I enter the valid phoneno only and press next$")
	public void i_enter_the_valid_phoneno_only_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conPageBean.setFirstName("Sai");
		conPageBean.setLastName("Praneetha");
		conPageBean.setEmail("prani@gmailcom");
		conPageBean.setPhone("1234567890");
	    conPageBean.setBtn();
	}

	@Then("^Alert message for no of people attending will be raised$")
	public void alert_message_for_no_of_people_attending_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Number of people attending");
    	Thread.sleep(500);
	}

	@When("^I enter the no of people attending and press next$")
	public void i_enter_the_no_of_people_attending_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conPageBean.setFirstName("Sai");
		conPageBean.setLastName("Praneetha");
		conPageBean.setEmail("prani@gmail.com");
		conPageBean.setPhone("1234567890");
		conPageBean.setPeopleAttending("3");
	    conPageBean.setBtn();
	}

	@Then("^Alert message for building no and room no will be raised$")
	public void alert_message_for_building_no_and_room_no_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Building & Room No");
    	Thread.sleep(500);
	}

	@When("^I enter the building no and room no and press next$")
	public void i_enter_the_building_no_and_room_no_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conPageBean.setFirstName("Sai");
		conPageBean.setLastName("Praneetha");
		conPageBean.setEmail("prani@gmail.com");
		conPageBean.setPhone("1234567890");
		conPageBean.setPeopleAttending("3");
		conPageBean.setBuildingName("23 cannopy");
	    conPageBean.setBtn();
	}

	@Then("^Alert message for enter area name will be raised$")
	public void alert_message_for_enter_area_name_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Area name");
    	Thread.sleep(500);
	}

	@When("^I enter the area name and press next$")
	public void i_enter_the_area_name_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conPageBean.setFirstName("Sai");
		conPageBean.setLastName("Praneetha");
		conPageBean.setEmail("prani@gmail.com");
		conPageBean.setPhone("1234567890");
		conPageBean.setPeopleAttending("3");
		conPageBean.setBuildingName("23 cannopy");
		conPageBean.setArea("Mahindra World City");
	    conPageBean.setBtn();
	}

	@Then("^Alert message for enter city will be raised$")
	public void alert_message_for_enter_city_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please select city");
    	Thread.sleep(500);
	}

	@When("^I enter the city and press next$")
	public void i_enter_the_city_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conPageBean.setFirstName("Sai");
		conPageBean.setLastName("Praneetha");
		conPageBean.setEmail("prani@gmail.com");
		conPageBean.setPhone("1234567890");
		conPageBean.setPeopleAttending("3");
		conPageBean.setBuildingName("23 cannopy");
		conPageBean.setArea("Mahindra World City");
		conPageBean.setCity("Chennai");
	    conPageBean.setBtn();
	}

	@Then("^Alert message for enter state will be raised$")
	public void alert_message_for_enter_state_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please select state");
    	Thread.sleep(500);
	}

	@When("^I enter the state and press next$")
	public void i_enter_the_state_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conPageBean.setFirstName("Sai");
		conPageBean.setLastName("Praneetha");
		conPageBean.setEmail("prani@gmail.com");
		conPageBean.setPhone("1234567890");
		conPageBean.setPeopleAttending("3");
		conPageBean.setBuildingName("23 cannopy");
		conPageBean.setArea("Mahindra World City");
		conPageBean.setCity("Chennai");
		conPageBean.setState("Tamilnadu");
	    conPageBean.setBtn();
	}

	@Then("^Alert message for enter membership status will be raised$")
	public void alert_message_for_enter_membership_status_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please Select MemeberShip status");
    	Thread.sleep(500);
	}

	@When("^I enter the membership status and press next$")
	public void i_enter_the_membership_status_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		conPageBean.setFirstName("Sai");
		conPageBean.setLastName("Praneetha");
		conPageBean.setEmail("prani@gmail.com");
		conPageBean.setPhone("1234567890");
		conPageBean.setPeopleAttending("3");
		conPageBean.setBuildingName("23 cannopy");
		conPageBean.setArea("Mahindra World City");
		conPageBean.setCity("Chennai");
		conPageBean.setState("Tamilnadu");
		conPageBean.setMemberStatus();
	    conPageBean.setBtn();
	}

	@Then("^I get an alert for Personal Details validated and I am sent to PaymentDetails\\.html page$")
	public void i_get_an_alert_for_Personal_Details_validated_and_I_am_sent_to_PaymentDetails_html_page() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Personal details are validated.");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
    	
	}

	@When("^Payment details page is open and i blinldly press payment$")
	public void payment_details_page_is_open_and_i_blinldly_press_payment() throws Throwable {
		payPageBean.setBtn2();
	}

	@Then("^Alert message for card holder name is raised$")
	public void alert_message_for_card_holder_name_is_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Card holder name");
    	Thread.sleep(500);
	}

	@When("^I enter card holder name and press next$")
	public void i_enter_card_holder_name_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
	    payPageBean.setCardHolderName("Sai Praneetha");
	    payPageBean.setBtn2();
	}

	@Then("^Alert message for enter debit card no will be raised$")
	public void alert_message_for_enter_debit_card_no_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Debit card Number");
    	Thread.sleep(500);
	}

	@When("^I enter the enter debit card no press next$")
	public void i_enter_the_enter_debit_card_no_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		 payPageBean.setCardHolderName("Sai Praneetha");
		 payPageBean.setDbCardNumber("1234123412341234");
		 payPageBean.setBtn2();
	}

	@Then("^Alert message for enter cvv no will be raised$")
	public void alert_message_for_enter_cvv_no_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the CVV");
    	Thread.sleep(500);
	}

	@When("^I enter the cvv no and press next$")
	public void i_enter_the_cvv_no_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		payPageBean.setCardHolderName("Sai Praneetha");
		 payPageBean.setDbCardNumber("1234123412341234");
		 payPageBean.setCvv("564");
		 payPageBean.setBtn2();
	}

	@Then("^Alert message for enter expiry month will be raised$")
	public void alert_message_for_enter_expiry_month_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill expiration month");
    	Thread.sleep(500);
	}

	@When("^I enter the expiry month and press next$")
	public void i_enter_the_expiry_month_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		payPageBean.setCardHolderName("Sai Praneetha");
		 payPageBean.setDbCardNumber("1234123412341234");
		 payPageBean.setCvv("564");
		 payPageBean.setExpiryDate("8");
		 payPageBean.setBtn2();
	}

	@Then("^Alert message for expiry year will be raised$")
	public void alert_message_for_expiry_year_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Please fill the expiration year");
    	Thread.sleep(500);
	}

	@When("^I enter the expiry year and press next$")
	public void i_enter_the_expiry_year_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		payPageBean.setCardHolderName("Sai Praneetha");
		 payPageBean.setDbCardNumber("1234123412341234");
		 payPageBean.setCvv("564");
		 payPageBean.setExpiryDate("08");
		 payPageBean.setExpiryYear("2020");
		 payPageBean.setBtn2();
	}

	@Then("^Alert for booking confirmation of room is raised$")
	public void alert_for_booking_confirmation_of_room_is_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(),"Conference Room Booking successfully done!!!");
    	Thread.sleep(500);
	}

	@After
	public void closeSetUp()
	{
		driver.close();
	}


}
