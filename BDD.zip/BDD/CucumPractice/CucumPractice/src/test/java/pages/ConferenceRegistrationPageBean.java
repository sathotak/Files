package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ConferenceRegistrationPageBean {
	
	WebDriver driver;
	
	@FindBy(name="txtFN")
	private WebElement firstName;
	
	@FindBy(name="txtLN")
	private WebElement lastName;

	@FindBy(name="Email")
	private WebElement email;
	
	@FindBy(name="Phone")
	private WebElement phone;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[5]/td[2]/select")
	private WebElement peopleAttending;
	
	@FindBy(name="Address")
	private WebElement buildingName;
	
	@FindBy(name="Address2")
	private WebElement area;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[9]/td[2]/select")
	private WebElement city;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[10]/td[2]/select")
	private WebElement state;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[12]/td[2]/input")
	private WebElement memberStatus;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[14]/td/a")
	private WebElement btn;
	
	public ConferenceRegistrationPageBean(WebDriver driver) {
		
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName); 
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}

	public void setPeopleAttending(String p) {
		Select sel= new Select(peopleAttending);
		sel.selectByVisibleText(p);
	}

	public void setBuildingName(String buildingName) {
		this.buildingName.sendKeys(buildingName);
	}

	public void setArea(String area) {
		this.area.sendKeys(area);
	}

	public void setCity(String c) {
		Select sel= new Select(city);
		sel.selectByVisibleText(c);
	}

	public void setState(String s) {
		Select st=new Select(state);
		st.selectByVisibleText(s);
	}

	public void setMemberStatus() {
		this.memberStatus.click();
	}

	public void setBtn() {
		this.btn.click();
	}
	
	
	
	/*public void setfirstName(String fName)
	{
		firstName.sendKeys(fName);
	}
	
	
	public void setlastName(String lName)
	{
		lastName.sendKeys(lName);
	}
	
	
	public void setEmail(String emailId)
	{
		email.sendKeys(emailId);
	}
	
	
	public void setPhone(String phoneNo)
	{
		phone.sendKeys(phoneNo);
	}
	*/
	
	
	
	

	
	
	

}
