package org.cap.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository("bankDao")

public class BankDaoImpl implements IBankDao {
	@PersistenceContext(type=PersistenceContextType.EXTENDED)
private EntityManager entityManager;
	private Customer user;
	
	@Transactional
	@Override
	public boolean validate(int username, String password) {
		
		user=entityManager.find(Customer.class, username);
		if(user!=null)
		if(username==(user.getCustomerId()) && password.equals(user.getCustomerPwd())) {
			return true;
		}
		return false;
		}
	@Transactional
	@Override
	public void createAccount(Account account) {
		account.setOpeningDate(new Date());
		account.setStatus("Active");
		account.setCustomer(user);
        Query query= entityManager.createQuery("select max(accountNo) from Account");
		
		List<Long> max= query.getResultList();
		
		account.setAccountNo(max.get(0)+1);
		entityManager.persist(account);
	}
	
	@Override
	public String getUserName() {
		if(user!=null) {
				return user.getFirstName();
			}
			return null;
			
	}
	@Transactional(readOnly=true)
	@Override
	public List<Long> getAccountNumbers() {
		Query query=entityManager.createQuery("select accountNo from Account where customerId=:custId");
		query.setParameter("custId", user.getCustomerId());
		List<Long> accountNos= query.getResultList();
		return accountNos;
	}
	
	
	
	@Transactional
	@Override
	public void depWithAccount(Transaction transaction) {
		long accNo=transaction.getFromAccount().getAccountNo();
		Query query=entityManager.createQuery("from Account where accountNo=:accNo");
		query.setParameter("accNo", accNo);
		List<Account> account= query.getResultList();
		transaction.setCustomer(user);
		transaction.setStatus("Completed");
		transaction.setTransactionDate(new Date());
		transaction.setFromAccount(account.get(0));
	
	entityManager.persist(transaction);
		
	}
	
	
	
	
	@Transactional(readOnly=true)
	@Override
	public Map<Account, Double> getAmoutCrDe(String strQuery){
	
		
		Query query2=entityManager
				.createQuery(strQuery);
		
		query2.setParameter("custId", user.getCustomerId());
		
		List<Transaction> transactions=query2.getResultList();
		Map<Account, Double> map=
		transactions.stream()
				.collect(
				Collectors.groupingBy(Transaction::getFromAccount,
					Collectors.summingDouble(Transaction::getAmount))
				);
		return map;
	}
	@Override
	@Transactional(readOnly=true)
	public List<Account> getAllAccountsOfCustomer() {
		
		Query query= entityManager
			.createQuery("from Account acc where acc.customer.customerId=:custId");
		
		query.setParameter("custId", user.getCustomerId());
		
		
		List<Account> accounts= query.getResultList();
		
		
		return accounts;
	}
	@Override
	public List<Account> getAllAccounts() {
		Query query= entityManager
				.createQuery("from Account acc where acc.customer.customerId!=:custId");
			
			query.setParameter("custId", user.getCustomerId());
			
			
			List<Account> accounts= query.getResultList();
			
			
			return accounts;
	}
	@Transactional
	@Override
		public void fundTransfer(Transaction transaction) {
		long FromAccNo=transaction.getFromAccount().getAccountNo();
		Query query=entityManager.createQuery("from Account where accountNo=:accNo");
		query.setParameter("accNo", FromAccNo);
		List<Account> account= query.getResultList();
		transaction.setCustomer(user);
		transaction.setStatus("Completed");
		transaction.setTransactionDate(new Date());
		transaction.setTransactionType("debit");
		transaction.setFromAccount(account.get(0));
		double amount=transaction.getAmount();
		System.out.println(amount);
		String desc=transaction.getDescription();
		System.out.println(desc);
		long toAccNo=transaction.getToAccount().getAccountNo();
		Query query1=entityManager.createQuery("from Account where accountNo=:accNo");
		query1.setParameter("accNo", toAccNo);
		List<Account> toAccount= query1.getResultList();
		transaction.setToAccount(toAccount.get(0));
		entityManager.persist(transaction);
		
		Transaction transaction1=new Transaction();
		Customer customer=new Customer();
		customer=toAccount.get(0).getCustomer();
		transaction1.setCustomer(customer);
		transaction1.setTransactionDate(new Date());
		transaction1.setFromAccount(toAccount.get(0));
		transaction1.setTransactionType("credit");
		transaction1.setAmount(amount);
		transaction1.setDescription(desc);
		entityManager.persist(transaction1);
		
		
	
		
	}
	@Override
	public List<Transaction> getTransactions() {
		Query query= entityManager
				.createQuery("from Transaction where customerId=:custId");
		    query.setParameter("custId", user.getCustomerId());
			List<Transaction> transactions= query.getResultList();
			return transactions;
	}
	
}
	


