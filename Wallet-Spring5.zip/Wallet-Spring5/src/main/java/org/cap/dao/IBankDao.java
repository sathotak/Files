package org.cap.dao;

import java.util.List;
import java.util.Map;
import org.cap.model.Account;
import org.cap.model.Transaction;



public interface IBankDao {
// public void savePilot(Pilot pilot);
 /*public List<Pilot> getAll();
 public void delete(Integer pilotId);
 public void edit(Pilot pilot1);*/
// public Customer findCustomer(Integer customerId);
 public boolean validate(int username, String password);
public void createAccount(Account account);
public String getUserName();
public List<Long> getAccountNumbers();
public void depWithAccount(Transaction transaction);



public Map<Account, Double> getAmoutCrDe(String strQuery);
public List<Account> getAllAccountsOfCustomer();
public List<Account> getAllAccounts();
public void fundTransfer(Transaction transaction1);
public List<Transaction> getTransactions();

}
