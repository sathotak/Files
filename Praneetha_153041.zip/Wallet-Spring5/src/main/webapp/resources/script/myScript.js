window.onload= function(){
	document.getElementById('years').style.display='none';
	document.getElementById('table').style.display='none';
	}
function myFunction() {
    alert("Invalid User");
}
function showButton(){
	if(document.getElementById('credit').checked){
		document.getElementById('btnType').value="Deposit";
	}else{
		document.getElementById('btnType').value="Withdraw";
	}
}
function validateForm(){
	var uname=myform.userName.value;
	var upwd=myform.userPwd.value;
	
	var flag=false;
	if(uname==""||uname==null){
		document.getElementById('userErrMsg').innerHTML=" * Please enter userName.";
		
	}
	else if(upwd=="" || upwd==null)
		{
		flag=false;
		document.getElementById('userErrMsg').innerHTML="";
		document.getElementById('pwdErrMsg').innerHTML=" * Please enter password.";
		}
	else{
		flag=true;
		document.getElementById('userErrMsg').innerHTML="";
		document.getElementById('pwdErrMsg').innerHTML="";
	}
		return flag;
}

function validForm(){
	var uname=myform.userName.value;
	var upwd=myform.userPwd.value;
	
	var flag=false;
	if(uname==""||uname==null){
		document.getElementById('userErrMsg').innerHTML=" * Please enter From Date.";
		
	}
	else if(upwd=="" || upwd==null)
		{
		flag=false;
		document.getElementById('userErrMsg').innerHTML="";
		document.getElementById('pwdErrMsg').innerHTML=" * Please enter To Date.";
		}
	else{
		flag=true;
		document.getElementById('userErrMsg').innerHTML="";
		document.getElementById('pwdErrMsg').innerHTML="";
	}
		return flag;
}

function showYear(){
	if(document.getElementById('rd').checked ||
			document.getElementById('fd').checked)
		document.getElementById('years').style.display='block';
	else
		document.getElementById('years').style.display='none';
}
function desc(){
	var desc=dwform.description.value;
	var amount=dwform.amount.value;
	var flag=false;
	if(desc==""||desc==null){
		document.getElementById('errMsg').innerHTML=" * Please enter description.";
		
	}
	else if(amount<=100){
		document.getElementById('errMsg1').innerHTML=" * Minimum amount is 100.";
	}
	else{
		flag=true;
		document.getElementById('errMsg').innerHTML="";
		document.getElementById('errMsg1').innerHTML="";
	}
	return flag;
}
function openingBal() {
	var opnBal=accform.openingBalance.value;
	var flag=false;
	if(document.getElementById('rd').checked)
		{
		if (opnBal<=500) {
			document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open RD is 500.";
		}
		else {
			flag=true;
			document.getElementById('errMsg').innerHTML="";
		}
		}
	else if (document.getElementById('fd').checked) {
		if (opnBal<=1000) {
			document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open FD is 1000.";
		}
		else {
			flag=true;
			document.getElementById('errMsg').innerHTML="";
		}
	}
	else if (document.getElementById('savings').checked) {
		if (opnBal<=500) {
			document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open Savings Acc is 500.";
		}
		else {
			flag=true;
			document.getElementById('errMsg').innerHTML="";
		}
	}
	else if (document.getElementById('current').checked) {
		if (opnBal<=10000) {
			document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open Current Acc is 10000.";
		}
		else {
			flag=true;
			document.getElementById('errMsg').innerHTML="";
		}
	}
	else{
		flag=true;
		document.getElementById('errMsg').innerHTML="";
	}
	return flag;
}