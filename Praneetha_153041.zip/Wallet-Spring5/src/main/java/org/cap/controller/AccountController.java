package org.cap.controller;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.cap.model.Account;
import org.cap.model.Transaction;
import org.cap.service.IBankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {
	@Autowired
	private IBankService bankService;
	private List<Transaction> transactions;
	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map,@RequestParam("userName")int customerId,@RequestParam("userPwd")String userPwd,HttpSession session) {
				boolean result=bankService.validate(customerId,userPwd);
		if(result)
		{
			//session.setAttribute("custId",customerId);
			String custName=bankService.getUserName();
			map.put("custName", custName);
		return "main";
		}
		else
		{
			return "redirect:/";
		}
    }
	

	@RequestMapping("/createAccount")
	public String showCreateAccountPage(ModelMap map) {
		map.put("account",new Account());
		return "createAccount";
	}
	@PostMapping("/saveAccount")
	public String saveAccount(@ModelAttribute("account") Account account) {
		
		bankService.createAccount(account);
		return "redirect:/createAccount";
	}
	@RequestMapping("/showBalance")
	public String showBalanceDetails(ModelMap map,
			HttpSession session) {
		
		//Integer custId= Integer.parseInt(session.getAttribute("custId").toString());
		List<Account> accounts= bankService.getAccountWithBalance();
		map.put("accounts", accounts);
		
		return "showBalance";
	}
	
	@RequestMapping("/deposit-withdraw")
	public String showdepositPage(ModelMap map) {
		map.put("transaction",new Transaction());
		List<Account> accounts=bankService.getAllAccountsOfCustomer();
		map.put("accounts",accounts);
		return "depositWithdraw";
		
	}
	@RequestMapping("/depWithMoney")
	public String depWithMoney(@ModelAttribute("transaction") Transaction transaction) {
		
		bankService.depWithAccount(transaction);
		return "redirect:/deposit-withdraw";
		
	}
	
		
	@RequestMapping("/fundTransfer")
	public String showFundTransferPage(ModelMap map) {
		List<Account> accounts=bankService.getAllAccountsOfCustomer();
		List<Account> allAccounts=bankService.getAllAccounts();
		map.put("trans",new Transaction());
		map.put("Custaccounts",accounts);
		map.put("accounts", allAccounts);
		return "fundTransfer";
		
	}
	@RequestMapping("/transferMoney")
	public String fundTransfer(@ModelAttribute("trans")Transaction transaction) {
		bankService.fundTransfer(transaction);
		return "redirect:/fundTransfer";
		
	}
	
	@RequestMapping("/transactions")
	public String showTranscationPage(ModelMap map) {
		map.put("trans",transactions);
		return "transactions";
		
	}
	
	@RequestMapping("/printTransactions")
	public String showTranscation(@RequestParam("date1")String date1,
			@RequestParam("date2")String date2,
			HttpSession session,ModelMap map) throws ParseException{
		System.out.println(date1);
		System.out.println(date2);
		
		Date d1=new SimpleDateFormat("yyyy-MM-dd").parse(date1);
		Date d2=new SimpleDateFormat("yyyy-MM-dd").parse(date2);	
		
		/*List<Transaction> transaction=accountService.printDatedTransactions(customerId,);
		List<Transaction> transactionDates=accountService.printTransactions(customerId);
		*/
		
		//map.put("transDate", transactionDates);
		 transactions=bankService.getTransactions(d1,d2);
		 
			
		return "redirect:/transactions";
		
	}
	@RequestMapping("/logout")
	public String showLoginPage(HttpSession session) {
		session.invalidate();
		return "redirect:/";
		
	}

}
