package org.capstore.rest.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.capstore.rest.model.Address;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
@Transactional
@Repository("capstoreDao")
public interface ICapstoreDao extends JpaRepository<Address, Integer> {
	 @Query("select a FROM Address a WHERE a.customers.custId=:customerId")
	   	public List<Address> findAddress(@Param("customerId")Integer custId);
	 
	/* @Query("select inventory.productId from WishList where customers.custId=:customerId")
		public List<Integer> findProducts(@Param("customerId")int custId); */
}
