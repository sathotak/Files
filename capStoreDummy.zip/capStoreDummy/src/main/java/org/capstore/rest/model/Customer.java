package org.capstore.rest.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler", "created"})
public class Customer {
	@Id
	@GeneratedValue
	private int custId;
	private String custName;
	@JsonIgnore
	@OneToMany(targetEntity=Address.class,mappedBy="customers")
	private List<Address> address;

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public List<Address> getAddress() {
		return address;
	}

	public void setWishList(List<Address> address1) {
		this.address = address1;
	}

	public Customer(int custId, String custName, List<Address> address1) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.address = address1;
	}
	public Customer() {
		
	}
	
	
	
}
