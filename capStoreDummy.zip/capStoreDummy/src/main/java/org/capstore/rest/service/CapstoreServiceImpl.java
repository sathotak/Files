package org.capstore.rest.service;

import java.util.List;
import java.util.Optional;

import org.capstore.rest.dao.ICapstoreDao;
import org.capstore.rest.model.Address;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("capstoreService")
public class CapstoreServiceImpl implements ICapstoreService {
    @Autowired
    private ICapstoreDao capstoreDao;
	

	@Override
	public List<Address> findAll(Integer custId) {
		List<Address> address=capstoreDao.findAddress(custId);
		return address;
	}
	
}
