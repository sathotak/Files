package org.capstore.rest.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler", "created"})
public class Address {

	@Id
	@GeneratedValue
	private int addressId;
	
	/*@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="customer_id")
	private Customer customer;*/
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="cust_id")
	private Customer customers;

	/*@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="merchantId")
	private Merchant merchant;*/
	private String streetNumber;
	private String city;
	private String state;
	private String country;
	private int zipcode; 
	
	/*@OneToOne
	@JoinColumn(name="shippingId")
	private Shipping shipping;*/
	
	public Address(int addressId, Customer customers, String streetNumber, String city, String state, String country,
			int zipcode) {
		super();
		this.addressId = addressId;
		this.customers = customers;
		this.streetNumber = streetNumber;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zipcode = zipcode;
		
	}
	public Address() {
		super();
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public Customer getCustomers() {
		return customers;
	}
	public void setCustomers(Customer customers) {
		this.customers = customers;
	}
	public String getStreetNumber() {
		return streetNumber;
	}
	public void setStreetNumber(String streetNumber) {
		this.streetNumber = streetNumber;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public int getZipcode() {
		return zipcode;
	}
	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}
	
	
}