package org.capstore.rest.controller;

import java.util.List;


import org.capstore.rest.model.Address;
import org.capstore.rest.service.ICapstoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/v1")
public class ShippingRestController {
@Autowired
private ICapstoreService capstoreService;
	
@GetMapping("/address/{custId}")
public ResponseEntity<List<Address>> getAllPilots(@PathVariable("custId") Integer custId){
	List<Address> address=capstoreService.findAll(custId);
 if(address.isEmpty()|| address==null)
	 return new ResponseEntity("sorry address with id does not exist",HttpStatus.NOT_FOUND);
 return new ResponseEntity<List<Address>>(address,HttpStatus.OK);
}


	
	
	
	
}
